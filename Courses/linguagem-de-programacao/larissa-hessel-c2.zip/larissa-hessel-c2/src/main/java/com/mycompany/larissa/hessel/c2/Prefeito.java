package com.mycompany.larissa.hessel.c2;

public class Prefeito extends Politico{

    public Prefeito() {
        this.CargoEstudando = "Prefeito";
        this.TempoDeGov = 4;
        this.Salario = 12000.00;
        this.OQueFaz = "Dirige o poder executivo em nível municipal";
    }
    
}
