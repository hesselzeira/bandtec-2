package com.mycompany.larissa.hessel.c2;

public class Senador extends Politico {

    public Senador() {

        this.CargoEstudando = "Senador";
        this.TempoDeGov = 8;
        this.Salario = 20000.00;
        this.OQueFaz = "Elabora e fiscaliza a aplicação de leis em nível nacional";

    }

}
