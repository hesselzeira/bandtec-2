package com.mycompany.larissa.hessel.c2;

public class Presidente extends Politico {

    public Presidente() {
         
        this.CargoEstudando = "Presidente";
        this.TempoDeGov = 4;
        this.Salario = 28000.00;
        this.OQueFaz = "Dirige o poder executivo em nível nacional";
        
    }
    
}
