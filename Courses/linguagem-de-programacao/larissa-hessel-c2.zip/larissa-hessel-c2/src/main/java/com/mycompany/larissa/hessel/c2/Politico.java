package com.mycompany.larissa.hessel.c2;

public class Politico {
    protected String CargoEstudando;
    protected Integer TempoDeGov;
    protected Double Salario;
    protected String OQueFaz;

    public String getCargoEstudando() {
        return CargoEstudando;
    }

    public Integer getTempoDeGov() {
        return TempoDeGov;
    }

    public Double getSalario() {
        return Salario;
    }

    public String getOQueFaz() {
        return OQueFaz;
    }

    
    
    
}
